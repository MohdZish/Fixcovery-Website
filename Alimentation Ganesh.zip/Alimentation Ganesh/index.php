<!DOCTYPE html>
<?php
  session_start();
  include("includes/db.php");
  include("functions/functions.php");

  include("includes/functions1.php");
?>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <link rel="icon" href="images/fevicon.png" type="image/gif" />
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>Alimentation Ganesh</title>


  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap" rel="stylesheet">

  <!-- font awesome style -->
  <link href="css/font-awesome.min.css" rel="stylesheet" />

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />

  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@500&display=swap" rel="stylesheet">

</head>

<body>

<script type="text/javascript">

   window.addEventListener('scroll',(e)=>{
        const nav = document.querySelector('.nav');
        if(window.pageYOffset>0){
          nav.classList.add("add-shadow");
        }else{
          nav.classList.remove("add-shadow");
        }
      });

  window.onload = function () {
    var myNav = document.getElementbyId("navtop") ;
    window.onscroll = function () { 
    "use strict";
    if (document.body.scrollTop >= 200 || document.documentElement.scrollTop >= 200 ) {
        myNav.classList.add("nav-colored");
        myNav.classList.remove("nav-transparent");
    } 
    else {
        myNav.classList.add("nav-transparent");
        myNav.classList.remove("nav-colored");
    }

    function myMap() {
    var mapProp = {
        center: new google.maps.LatLng(48.882720, 2.526010),
        zoom: 18
    };
    var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
}
}};

AOS.init({
  duration: 1500,  //FUNCTION FOR  ANIMATION FADE IN WHILE SCROLLING !!!
  once: true
})


function myFunction() {
  var input, filter, ul, li, a, i, txtValue;
  input = document.getElementById('myInput');
  filter = input.value.toUpperCase();
  ul = document.getElementById("myUL");
  li = document.getElementsByClassName('card-body');

  // Loop through all list items, and hide those who don't match the search query
  for (i = 0; i < li.length; i++) {
    a = li[i].getElementsByClassName("card-title")[0];

    if (a.innerText.toUpperCase().indexOf(filter) > -1) {
      li[i].parentNode.style.display = "";
    } else {
      li[i].parentNode.style.display = "none";
    }
  }
}

</script>

<!-- Google Map -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI&callback=myMap"></script>
  <!-- End Google Map -->

  <!-- header section strats -->
  <header class="header_section" id="navtop">
    <div class="container">
      <nav class="navbar navbar-expand-lg custom_nav-container fixed-top nav">
        <a class="navbar-brand pl-2" href="index.php">
          <span>Alimentation Ganesh</span>
        </a>

        <button class="navbar-toggler mr-2" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class=""> </span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav  ml-auto">
            <li class="nav-item active">
              <a class="nav-link navbuttons underline btn btn-primary" href="index.html">Accueil <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link navbuttons underline" href="about.html"> Produits</a>
            </li>
            <li class="nav-item">
              <a class="nav-link navbuttons underline" href="fruit.html">Promotions</a>
            </li>
            <li class="nav-item">
              <a class="nav-link navbuttons underline" href="blog.html">Nouveautés</a>
            </li>
            <li class="nav-item">
              <a class="nav-link navbuttons underline" href="contact.html">Nous contacter</a>
            </li>
          </ul>
        </div>
      </nav>
    </div>
  </header>
  <!-- end header section -->
  <!-- slider section -->
  <section class="slider_section ">
    <div id="customCarousel1" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <div class="container ">
            <div class="row">
              <div class="col-md-6 col-lg-5" data-aos="fade-right">
                
                  <div class="map_container" >
                    <div class="map">
                      <div id="googleMap"></div>
                    </div>
                  </div>
                  <div class="detail-box" data-aos="fade-up">
                  <h1 class="pt-3" >
                    Nous vendons les meilleurs produits !
                  </h1>
                  <p>
                    Lorum Ipsum text here</p>
                  <div class="btn-box">
                    <a href="" class="btn-1">
                      Nos produits
                    </a>
                    <a href="" class="btn-2">
                      Nous Contacter
                    </a>
                  </div>

                </div>
              </div>
              <div class="col-md-6 col-lg-7 " data-aos="fade-up">
                <div class="img-box" >
                  <img src="images/slider-img.png" alt="">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <ol class="carousel-indicators">
        <li data-target="#customCarousel1" data-slide-to="0" class="active"></li>
        <li data-target="#customCarousel1" data-slide-to="1"></li>
        <li data-target="#customCarousel1" data-slide-to="2"></li>
      </ol>
    </div>
  </section>
  <!-- end slider section -->

  <!-- product section -->
<div class="row mainregion layout_padding">
  <div class="col-lg-2 mx-auto sidemenu pl-4" data-aos="fade-right" >
      <?php include_once("leftsidemenu.php"); ?>
    </div>

  <section class="col-lg-8 " data-aos="fade-up">
    <div class="container">
      <div class="row">
        <h2 class="col mt-1 ml-4 mb-3 text-left mainheading" >
           <?php 

              //SERVER Query string is the value after ? in the URL that we pass when we click the sidebar buttons to navigate !!!!
              $PageType = $_SERVER['QUERY_STRING'];  

              if($PageType == ""){ //First time into website has no string after ? in URL
                echo "Tous Les Produits";
              }
              
              elseif($PageType == "Nouveautes"){ // When Promotion button is clicked
                echo "Nouveaux Produits";
              }

              elseif($PageType == "Promotions"){ // When Promotion button is clicked
                echo "Nos Promotions";
              }
              else{
                echo "<div btn btn-primary> $PageType</div>" ;
              }
              


              ?>
        </h2>
        <input class="col-md-4 form-control collapse width searchbar mt-sm-1 mt-md-1 ml-4 mr-4 mb-md-3 show" id="myInput" onkeyup="myFunction()" type="search" placeholder="Cherchez un produit!" >

        <h6 class="col-1 mt-1 d-none d-md-block"><button data-toggle="collapse" data-target="#myInput" class="btn searchbutton float-right mr-3"><i class="fas fa-search"></i></button></h6>
      </div>


      <div class="row  mx-auto pl-1 pr-1 mt-4 " >
               <?php 

              //SERVER Query string is the value after ? in the URL that we pass when we click the sidebar buttons to navigate !!!!
              $PageType = $_SERVER['QUERY_STRING'];  

              if($PageType == ""){ //First time into website has no string after ? in URL
                getPro("nouveautes");
              }

              elseif($PageType == "Promotions"){ // When Promotion button is clicked
                getPro("promotions");
              }

              elseif($PageType == "Nouveautes"){
                getPro("nouveautes");
              }
              
              else{
                getPro("tout");
              }


              ?>
      </div>
    </div>
  </section>

   <div class="col-lg-2 mx-auto leftbar" >

    </div>
</div>
  <!-- end product section -->


  <!-- offer section -->

  <section class="offer_section">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-7 px-0">
          <div class="box offer-box1">
            <img src="images/o1.jpg" alt="">
            <div class="detail-box">
              <h2>
                Upto 20% Off
              </h2>
              <a href="">
                Shop Now
              </a>
            </div>
          </div>
        </div>
        <div class="col-md-5 px-0">
          <div class="box offer-box2">
            <img src="images/o2.jpg" alt="">
            <div class="detail-box">
              <h2>
                Upto 10% Off
              </h2>
              <a href="">
                Shop Now
              </a>
            </div>
          </div>
          <div class="box offer-box3">
            <img src="images/o3.jpg" alt="">
            <div class="detail-box">
              <h2>
                Upto 15% Off
              </h2>
              <a href="">
                Shop Now
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end offer section -->

  <!-- about section -->

  <section class="about_section layout_padding">
    <div class="container  ">
      <div class="row">
        <div class="col-md-6 ">
          <div class="img-box">
            <img src="images/about-img.png" alt="">
          </div>
        </div>
        <div class="col-md-6">
          <div class="detail-box">
            <div class="heading_container">
              <h2>
                About Us
              </h2>
            </div>
            <p>
              Words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks </p>
            <a href="">
              Read More
            </a>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end about section -->

  <!-- contact section -->
  <section class="contact_section layout_padding">
    <div class="container">
      <div class="heading_container">
        <h2>
          Contact <span>Us</span>
        </h2>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form_container contact-form">
            <form action="">
              <div>
                <input type="text" placeholder="Your Name" />
              </div>
              <div>
                <input type="text" placeholder="Phone Number" />
              </div>
              <div>
                <input type="email" placeholder="Email" />
              </div>
              <div>
                <input type="text" class="message-box" placeholder="Message" />
              </div>
              <div class="btn_box">
                <button>
                  SEND
                </button>
              </div>
            </form>
          </div>
        </div>
        <div class="col-md-6">
          <div class="map_container">
            <div class="map">
              <div id="googleMap"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- end contact section -->

  <!-- footer section -->
 <div>
  <?php
    include("includes/footer.php");
  ?>
</div>
  <!-- footer section -->

  <!-- jQery -->
  <script src="js/jquery-3.4.1.min.js"></script>
  <!-- bootstrap js -->
  <script src="js/bootstrap.js"></script>
  <!-- custom js -->
  <script src="js/custom.js"></script>
  <!-- Google Map -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI&callback=myMap"></script>
  <!-- End Google Map -->

</body>

</html>