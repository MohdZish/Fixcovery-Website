<?php
	session_start();
	session_destroy();
	echo "<script>window.open('suban.php','_self')</script>";
?>