<?php
	if(!isset($_SESSION['admin_email']))
	{
		echo "<script>window.open('login.php', '_self')</script>";
	}
	else
	{

	?>

	<?php
		if(isset($_GET['active_product']))
		{
			$update_id = $_GET['active_product'];
			$update_pro = "update products set product_detail='2' where product_id='$update_id'";

			$run_update = mysqli_query($con, $update_pro);
			if($run_update)
			{
				
				echo "<script>window.open('admin.php?view_product', '_self')</script>";
			}
		}
	?>

<?php } ?>