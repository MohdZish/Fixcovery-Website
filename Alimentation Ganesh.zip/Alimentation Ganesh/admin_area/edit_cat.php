<?php
	if(!isset($_SESSION['admin_email']))
	{
		echo "<script>window.open('login.php','_self')</script>";
	}
	else
	{
?>
<?php
	if(isset($_GET['edit_cat']))
	{
		$edit_cat_id = $_GET['edit_cat'];
		$edit_cat_query = "select * from categories where cat_id='$edit_cat_id'";
		$run_edit = mysqli_query($con, $edit_cat_query);
		$row_edit=mysqli_fetch_array($run_edit);
		$cat_id=$row_edit['cat_id'];
		$cat_title=$row_edit['cat_title'];
		$cat_desc=$row_edit['cat_desc'];
	}
?>

<div class="row pt-3">
<div class="col-lg-12">
<div class="panel panel-default">
<div class="panel-heading">
<h3 class="panel-title">
<i class="fa fa-money fa-fw"></i>
Modifier la Catégorie	
</h3>	
</div>	
<div class="panel-body mt-3">
<form class="form-horizontal" action="" method="post">
<div class="form-group">
<label class="col-md-3 control-label">
Entrez le nouveau nom de la catégorie
</label>	
<div class="col-md-6">
<input type="text" name="cat_title" class="form-control" value="<?php echo $cat_title; ?>">	
</div>	
</div> 
<div class="form-group">
</div>
</div>
<div class="form-group">
<label class="col-md-3 control-label">	
</label>	
<div class="col-md-6">
<input type="submit" name="update" value="Mettre à jour" class=" btn-primary form-control">
</div>
</div>
</form>	
</div>
</div>	
</div>	
</div>
<?php
if(isset($_POST['update']))
{
	$cat_title=$_POST['cat_title'];

	$update_cat="update categories set cat_title='$cat_title' where cat_id='$cat_id'";
	$run_cat=mysqli_query($con,$update_cat);
	if($run_cat)
	{
		echo "<script>alert('Category has been updated Successfully')</script>";
			echo "<script>window.open('admin.php?view_categories','_self')</script>";
	}
}
?>

<?php } ?>