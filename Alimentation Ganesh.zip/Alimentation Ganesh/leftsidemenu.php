<div class=" sidemenu no-gutters ml-1 mr-1">
  <button  type="submit" class="row mx-auto mt-3 mt-md-5 text-md-left pl-3 btn btn-light w-100 promobtn text-left mb-3"  onclick="window.location = 'index.php?Promotions'">
    Promotions
  </button>
  <div class="row no-gutters mx-auto"> 
    <div class="col-6 col-md-12 mx-auto">
      <button class="btn btn-light btn-lg categorybuttons btn-block text-md-left mb-3" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
        Tous les produits
      </button>
      <div class="collapse" id="collapseExample">
        <?php
          $get_product = "select * from categories order by 1 ASC ";
          $run_products = mysqli_query($con, $get_product);
          while ($row = mysqli_fetch_array($run_products))
          {
            $cat_id = $row['cat_id'];
            $cat_title = $row['cat_title'];
            echo 
            "<button class='btn btn-light btn-lg bg-light w-100 text-md-left subcatbuttons ml-3 mb-2'>
                <a href='index.php?$cat_title'>
                $cat_title
                </a>
              </button>
            ";
          }
        ?>         
      </div>
      <button class="btn btn-light btn-lg categorybuttons btn-block text-md-left mb-3" onclick="window.location='index.php?Nouveautes'" data-toggle="collapse">
      Nouveautés
    </button>
  </div>
    <div class="col-6 col-md-12 mx-auto">
      <button class=" btn btn-light btn-lg categorybuttons btn-block text-md-left pl-3 w-100 collapsed mb-3" href="#submenu1" onclick="window.location='contactus.php'"data-toggle="collapse">
        Contact Us
      </button>
    </div>
  </div>
</div>