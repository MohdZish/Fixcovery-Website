<?php
	$db = mysqli_connect("localhost","root","","alimentationganesh");
	function getLeftBar()
	{

		echo 
		"
			
  			<div class='col-xs-12 col-sm-6 col-md-4 col-lg-2'>
    			<ul class='nav navbar-nav side-nav'>
      				
      				<li class='mt-1 btn btn-light promobtn text-left mb-1'  style='width:200px;'>
        				<a href='promotion.php'>
          					<i class='fa fa-star txt-warning mr-1' >
          					</i>
          					Promotions
        				</a>
      				</li>
      				
      				<li class='mt-5 btn btn-light promobtn text-left mb-3'  style='width:200px;'>
        				<a href='newarrivals.php'>
          					New Arrivals
        				</a>
      				</li>
      
      				<li class='mt-5 btn btn-light promobtn text-left mb-3'  style='width:200px;'>
        				<a href='index.php'>
          					All Products
        				</a>
      				</li>
      				<li class='mt-5 btn btn-light promobtn text-left mb-3'   style='width:200px;'>
        				<a href='paymentmode.php'>
          					Payment Mode
        				</a>
      				</li>

      				<li class='mt-5 btn btn-light promobtn text-left mb-3'   style='width:200px;'>
        				<a href='contactus.php'>
          					Contact Us
        				</a>
      				</li>
  
    			</ul>
  			</div>
    		
		";

	}

?>
